Write a program that takes 5 input params from the user, and prints them one by one
